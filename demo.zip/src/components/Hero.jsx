import { Play, Info, ArrowRight } from 'lucide-react';
import { motion } from 'framer-motion';
import { useState } from 'react';

export default function Hero() {

    return (
        <div className="relative h-screen w-full overflow-hidden flex items-center">

            {/* Dynamic Background with YouTube Embed */}
            <div className="absolute inset-0 z-0 select-none pointer-events-none">
                <iframe
                    className="w-full h-full object-cover scale-[1.35]"
                    src="https://www.youtube.com/embed/mRxAsmfM-EM?autoplay=1&mute=1&controls=0&loop=1&playlist=mRxAsmfM-EM&showinfo=0&rel=0&iv_load_policy=3&disablekb=1&modestbranding=1"
                    title="Hero Video"
                    allow="autoplay; encrypted-media"
                    frameBorder="0"
                    style={{ pointerEvents: 'none' }}
                />

                {/* Vignette & Gradients for Readability */}
                <div className="absolute inset-0 bg-gradient-to-r from-black via-black/50 to-transparent" />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent" />
            </div>

            <div className="relative z-10 w-full px-8 md:px-24 pl-24 md:pl-40 flex flex-col justify-center h-full">

                {/* Modern Label */}
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex items-center gap-3 mb-6"
                >
                    <span className="px-3 py-1 bg-srtb-green text-white text-[10px] font-black tracking-widest uppercase rounded-sm">INFO</span>
                    <span className="text-gray-300 text-sm font-medium tracking-wide border-l border-gray-500 pl-3">Édition Spéciale</span>
                </motion.div>

                {/* Massive Title with Texture */}
                <motion.h1
                    className="text-6xl md:text-8xl font-black text-white leading-none mb-6 tracking-tighter mix-blend-overlay opacity-90"
                    initial={{ opacity: 0, x: -50 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 1, ease: "easeOut" }}
                >
                    JOURNAL
                    <br />
                    DE 20H
                </motion.h1>
                <motion.h2
                    className="text-4xl md:text-5xl font-bold text-srtb-yellow -mt-4 mb-8 pl-2"
                    initial={{ opacity: 0, x: -30 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.2, duration: 1 }}
                >
                    L'Actualité en Direct
                </motion.h2>

                <motion.p
                    className="text-lg md:text-xl text-gray-200 mb-10 max-w-xl leading-relaxed border-l-4 border-srtb-green pl-6 py-2"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.4 }}
                >
                    Retrouvez toutes les informations nationales et internationales. Le grand rendez-vous de l'information sur la SRTB.
                </motion.p>

                <motion.div
                    className="flex items-center gap-6"
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.6 }}
                >
                    <button className="group relative px-8 py-4 bg-white text-black font-black text-lg rounded overflow-hidden flex items-center gap-3 hover:gap-5 transition-all">
                        <div className="absolute inset-0 bg-srtb-green translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
                        <Play className="w-5 h-5 relative z-10 group-hover:text-white transition-colors" />
                        <span className="relative z-10 group-hover:text-white transition-colors">REGARDER</span>
                    </button>

                    <button className="px-8 py-4 bg-white/10 backdrop-blur-md border border-white/20 text-white font-bold text-lg rounded hover:bg-white/20 transition-all">
                        PLUS D'INFOS
                    </button>
                </motion.div>
            </div>
        </div>
    );
}
