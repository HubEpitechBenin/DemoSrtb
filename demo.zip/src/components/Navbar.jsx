import { useState, useEffect } from 'react';
import { Search, Bell, User, Sun, Moon, Linkedin, Facebook, Instagram, Youtube, Phone } from 'lucide-react'; // Phone as WhatsApp placeholder if needed or import specific icon
import { motion } from 'framer-motion';
import { useTheme } from '../context/ThemeContext';

export default function Navbar({ sidebarWidth }) {
    const [isScrolled, setIsScrolled] = useState(false);
    const { theme, toggleTheme } = useTheme();

    useEffect(() => {
        const handleScroll = () => {
            setIsScrolled(window.scrollY > 50);
        };
        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    return (
        <motion.header
            className={`fixed top-0 right-0 z-[60] py-4 pr-8 md:pr-16 flex items-center justify-between transition-all duration-300 ${isScrolled
                ? 'bg-bg-primary/90 backdrop-blur-xl shadow-lg'
                : 'bg-transparent'
                }`}
            style={{
                left: sidebarWidth, // Dynamic left position based on sidebar state
                backgroundColor: isScrolled ? 'var(--bg-primary)' : 'transparent',
                borderBottom: isScrolled ? '1px solid var(--border-color)' : 'none'
            }}
            initial={{ y: -100 }}
            animate={{ y: 0, left: sidebarWidth }}
            transition={{ type: 'spring', stiffness: 400, damping: 40, mass: 0.8 }}
        >
            {/* Left side: Navigation Links (HIDDEN on mobile/small screens since menu is in sidebar) */}
            <div className="flex items-center gap-8 pl-8 md:pl-0">
                {/* Logo is now primarily in the sidebar, but we can keep a small breadcrumb or page title here if needed. 
                     For now, let's keep the links. */}
                <ul className="hidden lg:flex items-center gap-6 text-sm font-medium" style={{ color: 'var(--text-secondary)' }}>
                    <li className="hover:text-srtb-green cursor-pointer transition-colors">Direct</li>
                    <li className="hover:text-srtb-green cursor-pointer transition-colors">Infos</li>
                    <li className="hover:text-srtb-green cursor-pointer transition-colors">Sport</li>
                    <li className="hover:text-srtb-green cursor-pointer transition-colors">Culture</li>
                </ul>
            </div>

            {/* Right side: Actions & User */}
            <div className="flex items-center gap-4 md:gap-6" style={{ color: 'var(--text-primary)' }}>
                <Search className="w-5 h-5 cursor-pointer hover:text-srtb-green transition-colors" />

                {/* Theme Toggle */}
                <button
                    onClick={toggleTheme}
                    className="p-2 rounded-full hover:bg-srtb-green/10 transition-colors"
                    aria-label="Toggle theme"
                >
                    {theme === 'dark' ? (
                        <Sun className="w-5 h-5 text-srtb-yellow" />
                    ) : (
                        <Moon className="w-5 h-5 text-srtb-green" />
                    )}
                </button>

                <Bell className="w-5 h-5 cursor-pointer hover:text-srtb-yellow transition-colors" />

                <div className="flex items-center gap-2 cursor-pointer hover:opacity-80">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-srtb-green to-blue-600 flex items-center justify-center shadow-lg ring-2 ring-white/10">
                        <User className="w-5 h-5 text-white" />
                    </div>
                </div>
            </div>
        </motion.header>
    );
}
