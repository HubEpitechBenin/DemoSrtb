import { useState } from 'react';
import { motion } from 'framer-motion';
import { ThemeProvider } from './context/ThemeContext';
import Navbar from './components/Navbar';
import VerticalNav from './components/VerticalNav';
import Hero from './components/Hero';
import ContentRow from './components/ContentRow';
import AmbientBackground from './components/AmbientBackground';
import banner1 from './assets/banner1.png';
import banner2 from './assets/banner2.png';
import { SRTB_VIDEOS } from './data/youtubeData';

// Helper to filter/distribute videos
const getContent = (category, limit = 10) => {
  // Simple mock filter logic since we have a flat list mostly
  if (category === 'SPORT') {
    return SRTB_VIDEOS.filter(v =>
      v.snippet?.channelTitle?.includes('Sport') ||
      v.snippet?.title?.toLowerCase().includes('match') ||
      v.snippet?.title?.toLowerCase().includes('can') ||
      v.snippet?.title?.toLowerCase().includes('pétanque')
    ).slice(0, limit);
  }
  if (category === 'INFO') {
    return SRTB_VIDEOS.filter(v =>
      v.snippet?.title?.includes('JT') ||
      v.snippet?.title?.includes('Journal') ||
      v.snippet?.title?.toLowerCase().includes('politique') ||
      v.snippet?.channelTitle?.includes('Info')
    ).slice(0, limit);
  }
  if (category === 'CULTURE') {
    return SRTB_VIDEOS.filter(v =>
      !v.snippet?.title?.includes('JT') &&
      !v.snippet?.channelTitle?.includes('Sport')
    ).slice(0, limit);
  }
  return SRTB_VIDEOS.slice(0, limit);
};

function AppContent() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const sidebarWidth = isSidebarOpen ? '300px' : '80px'; // Matching VerticalNav widths

  return (
    <div style={{ backgroundColor: 'var(--bg-primary)', minHeight: '100vh', color: 'var(--text-primary)' }}>
      <AmbientBackground />

      {/* Sidebar - Controls the main layout state */}
      <VerticalNav isOpen={isSidebarOpen} setIsOpen={setIsSidebarOpen} />

      {/* Pass sidebar width to Navbar for dynamic positioning */}
      <Navbar sidebarWidth={sidebarWidth} />

      {/* Main Content Area */}
      <motion.div
        className="min-h-screen relative"
        animate={{
          marginLeft: sidebarWidth,
        }}
        transition={{
          type: 'spring',
          stiffness: 400,
          damping: 40,
          mass: 0.8
        }}
        style={{
          marginLeft: '80px', // Default initial state to prevent flash
          width: `calc(100% - ${sidebarWidth})`
        }}
      >
        <main className="relative z-10 w-full">
          <Hero />

          <div className="relative -mt-32 space-y-12 pb-20 overflow-hidden">

            {/* SECTION 1: News / Actualités */}
            <div className="pt-16">
              <div className="px-8 mb-6 flex items-center gap-4">
                <div className="w-1.5 h-8 bg-srtb-green rounded-full"></div>
                <h2 className="text-2xl font-black">À LA UNE</h2>
              </div>
              <ContentRow title="L'Actualité en Continu" items={getContent('INFO')} variant="wide" />
            </div>

            {/* AD BANNER 1 */}
            <div className="px-8 max-w-[1600px] mx-auto">
              <motion.div
                whileHover={{ scale: 1.01 }}
                className="rounded-2xl overflow-hidden shadow-2xl relative group cursor-pointer"
                style={{ border: '1px solid var(--border-color)' }}
              >
                <div className="absolute top-4 left-4 z-10 bg-black/60 backdrop-blur px-3 py-1 rounded text-xs font-bold text-white uppercase border border-white/20">Publicité</div>
                <img src={banner2} alt="CAN Banner" className="w-full h-auto" />
              </motion.div>
            </div>

            {/* SECTION 2: Sports */}
            <div>
              <div className="px-8 mb-6 flex items-center gap-4">
                <div className="w-1.5 h-8 bg-srtb-yellow rounded-full"></div>
                <h2 className="text-2xl font-black">SPORT & ÉMOTIONS</h2>
              </div>
              <ContentRow title="Les Meilleurs Moments du Sport" items={getContent('SPORT')} variant="default" />
            </div>

            {/* SECTION 3: Culture & Magazines */}
            <div className="py-12 bg-black/20">
              <div className="px-8 mb-6 flex items-center gap-4">
                <div className="w-1.5 h-8 bg-purple-500 rounded-full"></div>
                <h2 className="text-2xl font-black">DÉCOUVERTE & CULTURE</h2>
              </div>
              <ContentRow title="Magazines & Documentaires" items={getContent('CULTURE')} variant="large" />
            </div>

            {/* AD BANNER 2 */}
            <div className="px-8 max-w-[1600px] mx-auto">
              <div className="relative rounded-2xl overflow-hidden h-[400px] group">
                <img
                  src={banner1}
                  alt="Marché Public"
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent flex flex-col justify-end p-12">
                  <div className="absolute top-4 right-4 bg-srtb-yellow text-black px-3 py-1 rounded text-xs font-bold uppercase">Sponsorisé</div>
                  <h3 className="text-4xl font-black mb-4 text-white">Marché Public</h3>
                  <p className="text-gray-200 mb-6 max-w-xl">
                    La référence des appels d'offres au Bénin.
                  </p>
                  <button className="bg-white text-black font-bold px-8 py-3 rounded-full hover:bg-gray-200 transition-colors w-fit">
                    Explorer
                  </button>
                </div>
              </div>
            </div>

          </div>
        </main>

        {/* Footer */}
        <footer className="relative py-16 mt-20" style={{ borderTop: '1px solid var(--border-color)', backgroundColor: 'var(--bg-elevated)' }}>
          <div className="max-w-7xl mx-auto px-8 grid grid-cols-1 md:grid-cols-4 gap-12">
            <div>
              <h3 className="text-2xl font-black mb-4">
                <span className="text-srtb-green">B</span>
                <span style={{ color: 'var(--text-primary)' }}>PLAY</span>
              </h3>
              <p className="text-sm opacity-60 mb-6">
                L'expérience digitale de la SRTB.
                <br />Information, divertissement et culture en illimité.
              </p>

              {/* Social Media Links */}
              <div className="flex items-center gap-4">
                <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-[#E1306C] hover:text-white transition-all duration-300 group">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="opacity-70 group-hover:opacity-100"><rect width="20" height="20" x="2" y="2" rx="5" ry="5" /><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" /><line x1="17.5" x2="17.51" y1="6.5" y2="6.5" /></svg>
                </a>
                <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-[#1877F2] hover:text-white transition-all duration-300 group">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="opacity-70 group-hover:opacity-100"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" /></svg>
                </a>
                <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-[#FF0000] hover:text-white transition-all duration-300 group">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="opacity-70 group-hover:opacity-100"><path d="M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17" /><path d="m10 15 5-3-5-3z" /></svg>
                </a>
                <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-[#0A66C2] hover:text-white transition-all duration-300 group">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="opacity-70 group-hover:opacity-100"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z" /><rect width="4" height="12" x="2" y="9" /><circle cx="4" cy="4" r="2" /></svg>
                </a>
                <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-[#25D366] hover:text-white transition-all duration-300 group">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="opacity-70 group-hover:opacity-100"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" /></svg>
                </a>
              </div>
            </div>

            <div>
              <h4 className="font-bold mb-4 text-sm uppercase tracking-wider opacity-80">Chaînes</h4>
              <div className="space-y-2 text-sm opacity-60">
                <p className="hover:text-srtb-green cursor-pointer">Bénin TV</p>
                <p className="hover:text-srtb-green cursor-pointer">Bénin Sport</p>
                <p className="hover:text-srtb-green cursor-pointer">Alafia</p>
                <p className="hover:text-srtb-green cursor-pointer">Radio Bénin</p>
              </div>
            </div>

            <div>
              <h4 className="font-bold mb-4 text-sm uppercase tracking-wider opacity-80">Pratique</h4>
              <div className="space-y-2 text-sm opacity-60">
                <p className="hover:text-srtb-green cursor-pointer">Grille des programmes</p>
                <p className="hover:text-srtb-green cursor-pointer">Replay</p>
                <p className="hover:text-srtb-green cursor-pointer">Devenir Annonceur</p>
              </div>
            </div>

            <div>
              <h4 className="font-bold mb-4 text-sm uppercase tracking-wider opacity-80">Légal</h4>
              <div className="space-y-2 text-sm opacity-60">
                <p className="hover:text-srtb-green cursor-pointer">Mentions Légales</p>
                <p className="hover:text-srtb-green cursor-pointer">Politique de Confidentialité</p>
                <p className="hover:text-srtb-green cursor-pointer">CGU</p>
              </div>
            </div>
          </div>
          <div className="max-w-7xl mx-auto px-8 mt-12 pt-8 text-center text-xs opacity-40 border-t border-white/5">
            <p>&copy; 2026 SRTB - Tous droits réservés. Une réalisation digitale avancée.</p>
          </div>
        </footer>
      </motion.div>
    </div>
  );
}

function App() {
  return (
    <ThemeProvider>
      <AppContent />
    </ThemeProvider>
  );
}

export default App;